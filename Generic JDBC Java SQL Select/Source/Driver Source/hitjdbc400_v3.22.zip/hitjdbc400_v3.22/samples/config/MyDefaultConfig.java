/*
 * @(#)MyDefaultConfig.java 1.11 2002/10/2
 *
 * Copyright 2002 by Hit Software,
 * 4020 Moorpark Ave, San Jose, California, 95117, U.S.A.
 * All rights reserved.
 *
 */

// This java file is a sample to show how to create
// a custom configuration class for the JDBC/400 driver.
//
// How to use this file as a custom configuration class:
//
//    1. Open this file in a text editor.
//
//    2. Uncomment the lines that contain the default values
//       which you want to provide new default values.
//       The default values are assigned to the instance
//       variables of the parent class hit.as400.As400DefaultConfig.
//       You are essentially overriding the values set in
//       class hit.as400.As400DefaultConfig
//
//    3. It's recommended that you ovveride a variable
//       only if you wish to provide a new default value.
//       Otherwise, leave it commented.
//
//    4. All values must be Java String
//
//    5. Provide an implementation for the method
//       initializeConnection() if you wish
//
//    6. Save the file. If you wish to save this file with
//       a different file name, make sure the class name
//       and constructor name have the same new name.
//
//    7. Compile the file. Make sure, the file hitjdbc400.jar
//       which contains the driver is also in compilation
//       classpath
//
//    8. There are two ways to tell the driver to use this
//       configuration class when creating a new connection.
//       A) Use option config_class=ClassName
//       B) Use option libraries=@ClassName
//       For examples:
//         url = "jdbc:as400://mysrv:446;libraries=test;config_class=MyDefaultConfig";
//         url = "jdbc:db2://libraries=@MyDefaultConfig"
//       If you use the libraries=@ClassName option syntax then you'd need
//       to specify the actual libraries in the config. class.
//
//     Note that this class must extend hit.as400.As400DefaultConfig

import java.sql.*;

public class MyDefaultConfig extends hit.as400.As400DefaultConfig {
    public MyDefaultConfig() {
        //          portNumber="8471";
        //          user = "";
        //          password = "";
        //          connOption = "";
        //          namingConvention = "SQL";
        //          licenseKey = "";
        //          libraries = "hhung,andreal";
        //          ccsid = "37";
        //          usePackages = "NO";
        //          usePackageLib = "";
        //          usePackageName = "";
        //          allowPackageUpdate = "NO";
        //          isConvertCCSID65535 = "NO";
        //          fetchBlockSize = "1024";
        //          useSSL = "37";
        //          serverCertFingerPrint = "";
        //          caCertfingerPrint = "";
        //          silverStream = "NO";
        //          listAllLibraries = "NO";
        //          traceFile = "";
        //          catalogQualifier = "";
        //          connectionTimeout = "5";
        //          useUnqualifiedTableName = "NO";
    }
    public void   initializeConnection(java.sql.Connection conn)
    throws SQLException {
        // You can execute any java or JDBC code here
        // This method is called after the connection is made succesfully
        // The parameter conn is the handle to the actual connection
        // If you throw a SQLException in this method, the connection
        // will be considered failed by the calling application.

        // example code
        //try {
        //    Statement s = conn.createStatement();
        //    s.executeUpdate("SET CURRENT SQLID='ABC'");
        //    s.close();
        //} catch (SQLException e) {
        //    // Just print exception info, don't rethrow exception
        //    e.printStackTrace();
        //    System.out.println(e);
        //
        //}

        return;
    }
}
