This simple servlet allows you to enter connection
information and a SQL query, then retrieves data
and displays it on an HTML page.

Before you try to run this example, make sure:

Your web server is running in a development environment
where you can stop and restart the server.

A servlet engine is installed and configured correctly
to run with your web server. The servlet is installed
in the directory dictated by the servlet engine. The
CLASSPATH variable of the Servlet engine is set to include
the JDBC driver.

For example, on Windows systems this might be:

set CLASSPATH=%CLASSPATH%;c:\hitjdbc400.jar;c:\hitlicense.jar

The servlet pathname is correctly set in the HTML file and
the servlet source code. If you place the servlet in a
different location than /servlet/SqlServlet (dictated by
your web server setup), you will need to edit the path in
the HTML and java file and recompile the servlet code.

<form action="/servlet/SqlServlet" method="GET">

Running the Servlet

To run the example:

Display the SqlServlet.html page in a web browser.
Enter your JDBC URL connection information in the following
format. Be sure to set the IP Address and libraries to your
AS/400 system values.

jdbc:as400://hostname;libraries=mylibs

Enter a query that is appropriate for your database.

Click Submit Query.