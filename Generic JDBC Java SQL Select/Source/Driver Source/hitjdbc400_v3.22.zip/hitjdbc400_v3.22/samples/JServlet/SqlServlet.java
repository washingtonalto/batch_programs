
import java.io.*;
import java.util.*;
import java.sql.*;

import javax.servlet.*;
import javax.servlet.http.*;


/**
 * SqlServlet is an example of a servlet which connects to a remote DB
 * via JDBC and extracts some data. The user have to provide user, password,
 * connection and the query to be executed.
 *
 * @version 0.1 27 Jan 2000
 * <pre>Copyright (C) 2000 by Hit Software, Inc. All rights reserved.</pre>
 */
public class SqlServlet extends HttpServlet {

    public void doGet (HttpServletRequest req, HttpServletResponse res)
	throws ServletException, IOException
    {
	res.setContentType("text/html");
	PrintWriter out = res.getWriter();

	out.println("<html>");
	out.println("<head><title>Hit Sql Servlet</title></head>");
	out.println("<body>");

	String user = req.getParameter("user");
	String password = req.getParameter("password");
	String connection = req.getParameter("connection");
	String query = req.getParameter("query");

	out.println("<h1>Hit Sql Servlet</h1><form action=\"/servlet/SqlServlet\" method=\"GET\">");
	out.println("<table><tr><td>Connection:</td><td><input name=\"connection\" size=\"70\" value=\""+connection+"\"></td></tr>");
	out.println("<tr><td>User:</td><td><input name=\"user\" value=\""+user+"\"></td></tr>");
	out.println("<tr><td>Password:</td><td><input name=\"password\" type=\"password\" value=\""+password+"\"></td></tr>");
	out.println("<tr><td>Query:</td><td><textarea name=\"query\" cols=\"50\" rows=\"3\">"+query+"</textarea></td></tr></table>");
	out.println("<p><input type=\"Submit\"></form><p>");

	try {
		Class.forName("hit.as400.As400Driver");
		Connection conn = DriverManager.getConnection(connection, user, password);
		Statement smt = conn.createStatement();
		ResultSet resultSet = smt.executeQuery(query);
		ResultSetMetaData resultSetMetaData = resultSet.getMetaData();
		out.println("<TABLE BORDER=\"1\">");
		out.println("<TR>");
		int numberOfColumns = resultSetMetaData.getColumnCount();
		for (int i=0; i<numberOfColumns; i++) {
			out.println("<TH>"+resultSetMetaData.getColumnName(i+1)+"</TH>");
		}
		out.println("</TR>");

		for(int countRows=0;resultSet.next();countRows++) {
			out.println("<TR>");
			for (int i=0; i<numberOfColumns; i++) {
				out.println("<TD>");
				out.println(resultSet.getString(i+1));
				out.println("</TD>");
			}
			out.println("</TR>");
		}
		out.println("</TABLE>");
		smt.close();
		conn.close();

	} catch (Exception exception) {
		out.println("Exception: "+exception);
	}

	out.println("</body></html>");
    }



    public String getServletInfo() {
	return "A servlet that makes a JDBC connection and returns data";
    }
}
