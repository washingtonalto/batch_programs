Included in this directory is the hitSQL application
that allows you to connect to a database and execute
SQL statements. There is also a function in the Test
menu that allows you to perform a socket connection
test to verify that you can at least see the database
server.

Please see the file r.bat for an example on how to run the application.

(hitSQL will only return a maximum of 100 rows for result sets)