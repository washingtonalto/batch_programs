package sql;

import java.beans.*;
import java.sql.*;
import java.io.*;
import javax.servlet.http.*;


/**
 * SqlServlet is an example of a servlet which connects to a remote DB
 * via JDBC.
 *
 * @version 0.1 27 Jan 2000
 * <pre>Copyright (C) 2000 by Hit Software, Inc. All rights reserved.</pre>
 */
public class SqlBean implements HttpSessionBindingListener {

	Connection conn;

	public SqlBean() {
		try {
			Class.forName("hit.as400.As400Driver");

			//Insert your JDBC URL connection, username and password
			conn = DriverManager.getConnection("jdbc:as400://host:port","user","password");
			//System.out.println("JDBC Connected");
		} catch (Exception e) {
			System.err.println(e);
		}
	}

	public Connection getConn() {
		return conn;
	}

	// The Http Session Binding for the SqlBean: the two events tell the bean
	// when it is bound or unbound from the session
	public void valueBound (HttpSessionBindingEvent sessionEvent) {
		//Bound: nothing to do because we already opened the database connection
		//       with the constructor: it will last for the entire session
	}

	// Session is closing, close the database connection
	public void valueUnbound (HttpSessionBindingEvent sessionEvent) {
		if(conn != null) {
			try {
				conn.close();
			} catch (Exception e) {
				System.err.println(e);
			}
		}
	}


}
