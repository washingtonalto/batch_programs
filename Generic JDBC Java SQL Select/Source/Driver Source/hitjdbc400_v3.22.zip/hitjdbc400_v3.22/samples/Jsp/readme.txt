This sample jsp allows you to enter connection information
and a SQL query, then retrieves data and displays it on an
HTML page. Each time you return to the page to try a new
query, the application makes a new connection.

Before you try to run this example, make sure:

Your web server is running in a development environment
where you can stop and restart the server. Servlet and
JSP engines are installed and configured correctly to run
with your web server. The CLASSPATH variable of the JSP
engine is set to include the JDBC driver. For example,
on Windows systems this might be:

set CLASSPATH=%CLASSPATH%;c:\hitjdbc400.jar;c:\hitlicense.jar

Running the JSP Application:

Display the sql.html page in a web browser.

Enter your JDBC URL connection information in the following
format:

jdbc:as400://myas400;libraries=mylib

Be sure to set the IP Address and libraries to your AS/400
system values.

Enter a query that is appropriate for your database.

Click Submit Query.
