//
// sqlBrowser.java - an interactive sql applet (similar to wisql)
//
// Copyright (C) 1998 by Hit Software. All rights reserved.
//
// Note: Change the connection param in the html file before using.
//

import java.applet.*;                               // import java libraries
import java.awt.*;
import java.io.*;
import java.net.*;
import java.util.*;

import java.sql.*;                                  // java.sql or jdbc.sql

public class sqlBrowser extends Applet
{
    private TextArea user = null;

    private TextArea server = null;                 // the size of the text in here is limited to a few
                                                    // thousand characters on most platforms. therefore
                                                    // if you 'select * from largeTable' you will only see
                                                    // part of the result.

    private Connection connection = null;

    synchronized public void init()
    {
        setBackground(Color.white);                 // white background for this applet

        setLayout(new BorderLayout());

        Font courier = new Font("Courier",Font.PLAIN,12);

        user = new TextArea();

        user.setEditable(true);

        user.setFont(courier);

        add("North",user);

        server = new TextArea();

        server.setFont(courier);

        add("Center",server);

        add("South",new Button("Query"));

        try
        {
            String driver = getParameter("driver");                     // use driver specified in 'driver' parameter

            System.out.println("<" + driver + ">");
            if(driver != null) Class.forName(driver).newInstance();     // register driver with DriverManager

            String url = getParameter("connection");                    // get connection's url

            System.out.println("<" + url + ">");
			connection = DriverManager.getConnection(url,null,null);    // establish connection with server

            logln("Connected to " + connection);
        }

        catch(Exception se) {
            server.appendText("Connection failed because " + se + "\n");
            System.out.println(se.getMessage());
        }
}

    synchronized public boolean action(Event iEvent,Object iArgument)
    {
        if(iArgument.equals("Query"))                                   // user clicked the 'clear' button
        {
            String sql = user.getText();                                // read sql statement from user area

            // System.out.println("sqlBrowser.action - query is " + sql);

            try
            {
                clearLog();                                             // empty server area

                // System.out.println("sqlBrowser.action - creating statement...");

                Statement statement = connection.createStatement();     // create new statement

                System.out.println("sqlBrowser.action - statement is " + statement);

                boolean isResult = statement.execute(sql);              // execute this statement, will return true if first result is a result set

                for(boolean hasMore = true ; hasMore ; )                // scan all result sets and update counts from this statement
                {
                    logWarnings(connection.getWarnings());              // log warnings

                    if(isResult)                                        // if it's a result set
                    {
                        System.out.println("sqlBrowser.action - logging result");

                        ResultSet resultSet = statement.getResultSet(); // get current result set

                        logWarnings(statement.getWarnings());

                        logResultSet(resultSet);
                    }
                    else                                                // could be an update count or we could be done
                    {
                        System.out.println("sqlBrowser.action - logging update count");

                        int updateCount = statement.getUpdateCount();   // update count or -1 if we're done

                        if(updateCount != -1)                           // if this is an update count
                        {
                            logUpdateCount(updateCount);
                        }
                        else hasMore = false;                           // no more results for this statement
                    }

                    if(hasMore)                                         // if there's more
                    {
                        isResult = statement.getMoreResults();          // move on to the next result set
                    }
                }
            }

            catch(SQLException sqlEx)                                   // catch problems here
            {
                System.out.println("sqlBrowser.action - exception was raised " + sqlEx);

                logln("\n\nAn SQLException was raised:\n" + sqlEx);
            }

            return true;
        }

        return super.action(iEvent,iArgument);
    }

    private int columnWidth(ResultSetMetaData metadata,int columnIndex) throws SQLException
    {
        String name = metadata.getColumnName(columnIndex);

        int nameLen = name != null ? name.length() : 0;

        return Math.max(metadata.getColumnDisplaySize(columnIndex),nameLen);

    }

    private String resizeString(String s,int len)
    {
        if(s == null) s = "";

        int slen = s.length();

        if(slen > len)
        {
            return s.substring(0,len);
        }

        for(int i = len - slen ; i > 0 ; i--) s += " ";

        return s;
    }

    private void logResultSet(ResultSet resultSet) throws SQLException
    {
        logln("\n\n-----------------------------------------------------------------------------------------------\n");

        // logln("\n\n-----\n");

        boolean isVirgin = true;

        int columns = 0, widths [] = null;

        while(resultSet.next())
        {
            // System.out.println("sqlBrowser.logResultSet - one more row...");

            if(isVirgin)
            {
                ResultSetMetaData metadata = resultSet.getMetaData();

                columns = metadata.getColumnCount();

                // System.out.println("sqlBrowser.logResultSet - got " + columns + " columns " + metadata);

                String s1 = "Result set has " + (columns != 1 ? columns + " columns" : "one column") + ".\n\n";

                s1 += metadata.toString() + "\n\n";

                widths = new int[columns + 1];

                for(int i = 1 ; i <= columns ; i++)
                {
                    widths[i] = columnWidth(metadata,i);

                    s1 += resizeString(metadata.getColumnLabel(i),widths[i]) + " ";
                }

                s1 += "\n";

                for(int i = 1 ; i <= columns ; i++, s1 += " ")
                {
                    for(int j = 0 ; j < widths[i] ; j++) s1 += "-";
                }

                logln(s1);

                isVirgin = false;
            }

            // System.out.println("sqlBrowser.logResultSet - here we go...");

            logWarnings(resultSet.getWarnings());

            String s2 = "";

            for(int i = 1 ; i <= columns ; i++)
            {
/*
                Object obj = resultSet.getObject(i);

                // System.out.println("sqlBrowser - object " + i + " is " + obj);

                String item = obj != null ? obj.toString() : "null";
*/
                String item = resultSet.getString(i);

                // System.out.println("sqlBrowser - object " + i + " is " + item);

                if(resultSet.wasNull()) item = "null";

                s2 += resizeString(item,widths[i]) + " ";
            }

            logln(s2);
        }
    }

    private void logUpdateCount(int updateCount) throws SQLException
    {
        // logln("\n\n-----------------------------------------------------------------------------------------------\n");

        logln("\n\n-----\n");

        logln("Update Count is " + updateCount + ".");
    }

    private void logWarnings(SQLWarning warning) throws SQLException
    {
        if(warning != null)
        {
            // logln("\n\n-----------------------------------------------------------------------------------------------\n");

            logln("\n\n-----\n");
        }

        while(warning != null)
        {
            logln("\n\nSQLWarning - " + warning.getSQLState() + " " + warning.getMessage() + " " + warning.getErrorCode());

            warning = warning.getNextWarning();
        }
    }

    String log = "";

    synchronized public void clearLog()
    {
        server.setText("");
    }

    synchronized public void log(String s)
    {
        server.appendText(s);
    }

    void logln(String s)
    {
        log(s + "\n");
    }
}
