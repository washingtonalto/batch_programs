sqlBrowser Applet Installation and Running Instructions

(*) Put the files sqlBrowser.html, sqlBrowser.class,
    hitjdbc400.jar, hitlicense.jar in a directory on
    your web server

(*) Edit sqlBrowser.html to specify connection parameters

(*) Make sure the IP Address of your database is the same
    as the address of your web server unless you are running
    HiT SSL Server on the web server

Troubles Shooting:

If the applet is not connecting to your database,
make sure you changed the 'connection' parameter
in sqlBrowser.html (replace '1.1.1.1' with your
database host name, eg: mycompany.com).

The connection's url tells the applet which database
on which host you're connecting too. Also make sure
you specify a valid login and password on your server.

If the applet is having troubles finding the code
for the driver, make sure you have the driver and
license jar files in the same directory where sqlBrowser.html
and .class are located on your web server.

If you're running the applet locally using AppletViewer,
or similar, make sure your CLASSPATH contains a path to
the driver and license jar files.

If you get a security exception, make sure that your
web server and your database are on the same machine,
i.e. they must have the same address. If not, you
have to run Hit SSL Server on your web server so that
your applet can connect to the database via the application.