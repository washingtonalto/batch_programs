// quickSQLUpdate.java
// To run: java quickSQLUpdate <server-address> <user> <password>

import java.lang.*;
import java.io.*;
import java.net.*;
import java.util.*;

import java.sql.*;

public class quickSQLUpdate {

    public quickSQLUpdate () {}

    static public void main(String args[]) {

        try {
			if ((args.length != 3)&&(args.length !=4)) {
				System.out.println("Invalid number of arguments, expects: <server-address> <user> <password>");
				System.out.println("                                      <server-address> <option> <user> <password>");
				return;
			}
			String driver,serverAdr,user,password;
			if (args.length ==3) {
				driver    = "hit.as400.As400Driver";
				serverAdr = args[0];
				user      = args[1];
				password  = args[2];
			}
			else {
				driver    = "hit.as400.As400Driver";
				serverAdr = args[0];
				args[1]=args[1].replace(':',';');
				serverAdr=serverAdr+";"+args[1];
				user      = args[2];
				password  = args[3];
			}

            // To enable JDBC driver tracing and direct the trace into a file,
            // please uncomment the next line and recompile the application

            //DriverManager.setLogStream(new PrintStream(new FileOutputStream("jdbc-trace.txt")));

            String connectOptions = "ccsid=37;fetch_block_size=64";
            DataInputStream stdIn = new DataInputStream(System.in);
            System.out.println("Instanciated " + Class.forName(driver));
            Connection conn = DriverManager.getConnection("jdbc:as400://" + serverAdr + ";" + connectOptions, user, password);
            System.out.println("Use quickSQLUpdate to execute DDL,UPDATE,DELETE,INSERT statements only.\n");

            String userInput;

            for (;;) {
                System.out.print("quickSQLUpdate> ");
                if ((userInput = stdIn.readLine()) == null) break;
				if (userInput.trim().length() == 0) continue;
                try {
                    Statement stmnt = conn.createStatement();
                    int updateCount = stmnt.executeUpdate(userInput);
                    System.out.println("Update count: " + updateCount);
                    stmnt.close();
                }
                catch (SQLException e) {
                    System.err.println("SQL Exception: " + e.getMessage());
                    System.err.println("SQL State:     " + e.getSQLState());
                    System.err.println("Vendor Code:   " + e.getErrorCode());
                }
                catch (Exception oe) {
                    oe.printStackTrace(System.err);
                }
            } // end for
            conn.close();
        }
        catch (Exception ex) {
            System.err.println("Exception: " + ex.getMessage());
        }
    }
}

