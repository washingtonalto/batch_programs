// quickSQLSelect.java
// To run: java quickSQLSelect <server-address> <user> <password>

import java.lang.*;
import java.io.*;
import java.net.*;
import java.util.*;

import java.sql.*;

public class quickSQLSelect {

    public quickSQLSelect () {}

    static public void main(String args[]) {

        try {
			if ((args.length != 3)&&(args.length !=4)) {
				System.out.println("Invalid number of arguments, expects: <server-address> <user> <password>");
				System.out.println("                                      <server-address> <option> <user> <password>");
				return;
			}
			String driver,serverAdr,user,password;
			if (args.length ==3) {
				driver    = "hit.as400.As400Driver";
				serverAdr = args[0];
				user      = args[1];
				password  = args[2];
			}
			else {
				driver    = "hit.as400.As400Driver";
				serverAdr = args[0];
				args[1]=args[1].replace(':',';');
				serverAdr=serverAdr+";"+args[1];
				user      = args[2];
				password  = args[3];
			}


            // To enable JDBC driver tracing and direct the trace into a file,
            // please uncomment the next line and recompile the application

            //DriverManager.setLogStream(new PrintStream(new FileOutputStream("jdbc-trace.txt")));

            String connectOptions = "ccsid=37;fetch_block_size=64";
            DataInputStream stdIn = new DataInputStream(System.in);
            System.out.println("Instanciated " + Class.forName(driver));
            Connection conn = DriverManager.getConnection("jdbc:as400://" + serverAdr + ";" + connectOptions, user, password);
            System.out.println("Use quickSQLSelect to execute SELECT statements only.\n");

            String userInput;

            for (;;) {
                System.out.print("quickSQLSelect> ");
                if ((userInput = stdIn.readLine()) == null) break;
				if (userInput.trim().length() == 0) continue;
                try {
                    Statement stmnt = conn.createStatement();
                    printResultSet("", stmnt.executeQuery(userInput));
                    stmnt.close();
                }
                catch (SQLException e) {
                    System.err.println("SQL Exception: " + e.getMessage());
                    System.err.println("SQL State:     " + e.getSQLState());
                    System.err.println("Vendor Code:   " + e.getErrorCode());
                }
                catch (Exception oe) {
                    oe.printStackTrace(System.err);
                }
            } // end for
            conn.close();
        }
        catch (Exception ex) {
            System.err.println("Exception: " + ex.getMessage());
        }
    }

    static void printResultSet(String msg, ResultSet rs)
    {
        try {
            System.out.println(msg);
			ResultSetMetaData rsmd = rs.getMetaData();
            System.out.println(rsmd.toString()+"\n");
            for (int i=0; rs.next();) {
                System.out.print("#" + (++i) + " ");
   			    for (int j = 1; j <= rsmd.getColumnCount(); j++) {
                    if (j == 1) System.out.print("<");
                    String s = null;
                    try {
                        s = rs.getString(j);
                    } catch (Exception e2) {
                        System.out.print(e2.getMessage());
                    }
                    s = (s == null) ? "null" : s.trim();
                    try {
                        System.out.print(s);
                    } catch (Exception e1) {
                        System.out.print(e1.getMessage());
                    }
                    System.out.print((j == rsmd.getColumnCount()) ? ">" : ", ");
                }
                System.out.println("");
            }
            System.out.println("");
        } catch (Exception e) {System.out.println("Print Exception: " + e.getMessage());}
    }

}

