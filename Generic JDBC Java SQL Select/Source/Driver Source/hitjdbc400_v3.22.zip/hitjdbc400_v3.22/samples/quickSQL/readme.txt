Included in this directory are sample applications
that allow you to execute SQL statements.
Please feel free to browse the source codes.

All applications expect these 3 parameters: <url> <userid> <password>

* quickSQL        - can be used to execute any SQL statement
* quickSQLQuery   - can be used to execute SELECT statement
* quickSQLUpdate  - can be used to execute DDL, UPDATE, DELETE, INSERT statements

See the file r.bat    for an example on how to run the applications
See the file rssl.bat for an example on how to run the applications with SSL

If you use these sample applications on an AS/400 you need these
4 parameters: <url> <option> <userid> <password>

Example:
java quickSQL 1.1.1.1 libraries=mylib userid password


