This is a simple Weblogic Bean-managed EJB application demonstrating
the use of Hit JDBC JCA driver. This example contains the following:
 + hitjcasample dir                 
    + sample dir
       - build.xml             Ant build file
       - AccountBean.java      Persistence bean
       - AccountHome.java      Bean home interface
       - Account.java          Bean remote interface
       - Servlet.java          Servlet that will access bean
       - weblogic-ejb-jar.xml  Weblogic ejb xml
       - ejb-jar.xml           EJB xml
       + rars
          - build.xml          Ant build file
          - hitjca400.rar      Hit jca rar file. If it's not included, please 
                               copy this file from HIT_DIR/rar_builder folder. The readme
                               file under HIT_DIR/rar_builder contains instruction on how
                               to build the rar file.


Here are steps to build and deploy the example. These instructions assume EXAMPLE server is 
being used.

1 - Open a command line shell and cd to WEBLOGIC7_ROOT\samples\server\config\examples and
    execute setExamplesEnv.cmd.

2 - Copy folder HIT_ROOT\samples\hitjcasample to WEBLOGIC7_ROOT\samples\server\src\examples

3 - Edit HIT_ROOT\rar_builder\weblogic-ra.xml and enter the information like user, password,
    db2 server IP ... 

4 - Run ant with target rar_weblogic to build hitjca400.rar.

5 - Copy HIT_ROOT\rar_builder\hitjca400.rar to WEBLOGIC7_ROOT\samples\server\src\examples\hitjcasample\sample\rars

6 - CD to WEBLOGIC7_ROOT\samples\server\src\examples\hitjcasample\sample and
    run ant with default target. The ant script will compile, build and copy the jars to 
    proper folder:
       - Build and place hit400jcasample.jar in WEBLOGIC7_ROOT\samples\server\config\examples\applications 
       - Compile and place servlet in WEBLOGIC7_ROOT\samples\server\stage\examples\examplesWebApp\WEB-INF\classes

7 - Edit file WEBLOGIC7_ROOT\samples\server\stage\examples\examplesWebApp\WEB-INF\web.xml and add:
    - <servlet>
           <servlet-name>hitjcasample</servlet-name> 
           <servlet-class>examples.hitjcasample.sample.Servlet</servlet-class> 
      </servlet>
    - <servlet-mapping>
           <servlet-name>hitjcasample</servlet-name> 
           <url-pattern>/hitjcasample/*</url-pattern> 
      </servlet-mapping>

8 - Using example quickSQL.jar, or any other application to create a test table:
    create table hitjcatesttable (id varchar(40) primary key, bal double)

9 - Start up Weblogic example server using Internet Explorer and type in:
    http://localhost:7001/examplesWebApp/hitjcasample. 

    This will execute the servlet and in turn activate the bean. 
    It creates a new account (11), displays the current
    balance, makes a deposit, displays the balance again and finally deletes the account.
    The result will look like this:
               Creating account number one... 
               account 11 created! 

               Account Number: 11 
               Balance: 1111.0 

               Making a deposit ... 

               Account Number: 11 
               New Balance: 2111.0 

               Deleting account ... 

               End HitSW testing beanManaged.Servlet... 


