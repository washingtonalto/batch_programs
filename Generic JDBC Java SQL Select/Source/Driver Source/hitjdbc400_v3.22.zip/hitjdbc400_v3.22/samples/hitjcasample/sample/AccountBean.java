package examples.hitjcasample.sample;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Enumeration;
import java.util.Vector;

import javax.ejb.CreateException;
import javax.ejb.DuplicateKeyException;
import javax.ejb.EJBException;
import javax.ejb.EntityBean;
import javax.ejb.EntityContext;
import javax.ejb.FinderException;
import javax.ejb.NoSuchEntityException;
import javax.ejb.ObjectNotFoundException;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

/**
 * AccountBean (EntityBean). 
 */
public class AccountBean implements EntityBean {
    
    private EntityContext ctx;
    private String accountId;
    private double balance;

    public void setEntityContext(EntityContext ctx) {
        this.ctx = ctx;
    }
    
    public void unsetEntityContext() {
        this.ctx = null;
    }
    
    public void ejbActivate() {
        //not use
    }
    
    public void ejbPassivate() {
        //not use
    }
    
    //load ejb
    public void ejbLoad() {
        //not use
    }

    //store
    public void ejbStore() {
        Connection con = null;
        PreparedStatement ps = null;
        
        try {
            con = getConnection();
            ps = con.prepareStatement("update hitjcatesttable set bal = ? where id = ?");
            ps.setDouble(1, balance);
            ps.setString(2, accountId);
            if (!(ps.executeUpdate() > 0)) {
                throw new NoSuchEntityException ("Error storing data ...");
            }
        } catch(SQLException sqe) {
            throw new EJBException (sqe);
        } finally {
            closeResources(con, ps);
        }
    }


    //create method for create() in Home
    public String ejbCreate(String accountId, double initialBalance)
        throws CreateException {
        this.accountId = accountId;
        this.balance = initialBalance;
        
        Connection con = null;
        PreparedStatement ps = null;
        
        try {
            con = getConnection();
            ps = con.prepareStatement("insert into hitjcatesttable (id, bal) values (?, ?)");
            ps.setString(1, accountId);
            ps.setDouble(2, balance);
            if (ps.executeUpdate() != 1) {
                throw new CreateException ("Exception updating ...");
            }
            
            return accountId;
        } catch (SQLException sqe) {
            try {
                ejbFindByPrimaryKey(accountId);
            } catch(ObjectNotFoundException onfe) {
                throw new CreateException ("Exception creating ejb...");
            }
            throw new DuplicateKeyException("Key exists...");
        } finally {
            closeResources(con, ps);
        }
    }

    public void ejbPostCreate(String accountId, double initialBalance) {
        //not use
    }

    // delete account 
    public void ejbRemove() {
        Connection con = null;
        PreparedStatement ps = null;
        
        try {
            con = getConnection();
            accountId = (String) ctx.getPrimaryKey();
            ps = con.prepareStatement("delete from hitjcatesttable where id = ?");
            ps.setString(1, accountId);
            if (!(ps.executeUpdate() > 0)) {
                throw new NoSuchEntityException ("Exception removing account ...");
            }
        } catch (SQLException sqe) {
            throw new EJBException (sqe);
        } finally {
            closeResources(con, ps);
        }
    }
    
    //find primary key
    public String ejbFindByPrimaryKey(String pk)
        throws ObjectNotFoundException {

        Connection con = null;
        PreparedStatement ps = null;

        try {
            con = getConnection();
            ps  = con.prepareStatement("select bal from hitjcatesttable where id = ?");
            ps.setString(1, pk);
            ps.executeQuery();
            ResultSet rs = ps.getResultSet();
            if (rs.next()) {
                balance = rs.getDouble(1);
            } else {
                throw new ObjectNotFoundException ("Account does not exist ...");
            }
        } catch (SQLException sqe) {
            throw new EJBException (sqe);
        } finally {
            closeResources(con, ps);
        }
        return pk;
    }


    /**
     * Adds amount to balance.
     *
     * @param amount            double Amount
     * @return                  double balance
     */
    public double deposit(double amount) {
        balance += amount;
        this.ejbStore();
        return balance;
    }

    /**
     * Returns current balance.
     *
     * @return                  double Balance
     */
    public double balance() {
        return balance;
    }

    /**
     * Gets current connection to the connection pool.
     *
     * @return                  Connection
     * @exception               javax.ejb.EJBException
     *                          if there is a communications or systems failure
     */
    private Connection getConnection() throws SQLException {
        InitialContext initCtx = null;
        try {
            initCtx = new InitialContext();
            DataSource ds = (javax.sql.DataSource)
                //initCtx.lookup("java:comp/env/eis/BlackBoxNoTx");
                initCtx.lookup("java:comp/env/eis/hit400jca");
            return ds.getConnection();
        } catch(NamingException ne) {
            throw new EJBException(ne);
        } finally {
            try {
                if(initCtx != null) initCtx.close();
            } catch(NamingException ne) {
                throw new EJBException(ne);
            }
        }
    }
    
    
    private String id() {
        return  (String) ctx.getPrimaryKey();
    }

    private void closeResources(Connection con, PreparedStatement ps) {
        try {
            if (ps != null) ps.close();
        } catch (Exception e) {
            throw new EJBException (e);
        }

        try {
            if (con != null) con.close();
        } catch (Exception e) {
            throw new EJBException (e);

        }
    }
}

