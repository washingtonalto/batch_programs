package examples.hitjcasample.sample;

import javax.ejb.CreateException;
import javax.ejb.EJBHome;
import javax.ejb.FinderException;
import java.rmi.RemoteException;
import java.util.Enumeration;

/**
 * Home interface for the EJBean AccountBean.
 */
public interface AccountHome extends EJBHome {

  /**
   * This method corresponds to the ejbCreate method in the bean
   * AccountBean
   */
  public Account create(String accountId, double initialBalance)
    throws CreateException, RemoteException;

  /**
   * Find the EJBean with a given Primary Key
   */
  public Account findByPrimaryKey(String primaryKey)
    throws FinderException, RemoteException;

}
