package examples.hitjcasample.sample;

import java.rmi.RemoteException;
import javax.ejb.EJBObject;

/**
 * Remote interface.
 */
public interface Account extends EJBObject {

    //deposit
    public double deposit(double amount) throws RemoteException;
    
    //balance
    public double balance() throws RemoteException;

}



