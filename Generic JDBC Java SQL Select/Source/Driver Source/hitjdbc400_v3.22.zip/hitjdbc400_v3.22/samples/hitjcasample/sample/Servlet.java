package examples.hitjcasample.sample;

import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.rmi.RemoteException;
import java.util.Enumeration;
import java.util.Properties;
import java.util.Vector;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Register for this servlet at web.xml.
 * Web browser URL is: http://localhost:7001/examplesWebApp/hitjcasample
 * This servlet will create three accounts, make deposits, display
 * all accounts and then delete when done.
 * User need to create a testing table called hitjcatesttable:
 * create table hitjcatesttable (id varchar(40) primary key, bal double)
 */
public class Servlet extends HttpServlet {

    static String accountId    = "11";

    /**
     * Service method
     */
    public void service(HttpServletRequest req, HttpServletResponse res)
        throws IOException
    {
        res.setContentType("text/html");
        PrintWriter out = res.getWriter();

        printLine("<html><head><title>HitSoftware Example - EJBean Bean-managed Persistence Servlet</title></head><body>", out);

        printLine("", out);

        // Get parameters off URL; example:
        // "http://localhost:7001/jconnector?user=foobar&password=FooBarNone"

        String user     = req.getParameter("user");
        String password = req.getParameter("password");

        if(user!=null && password!=null){
            printLine("Using user <b>" + user
                      + "</b> and password <b> " + password + "</b>", out);
            printLine("", out);
        } else {
            printLine("No user and password credentials", out);
            printLine("", out);
        }

        double balance = 1111;


        try {
            // Contact the AccountBean container (the "AccountHome") through JNDI.
            Context ctx = getInitialContext();
            AccountHome home = (AccountHome) ctx.lookup("hit400jcasample.AccountHome");

            //create three accounts
            Account acc = null; //, acc2 = null, acc3 = null;
            try {
                printLine("Creating account number one...", out);
                acc = home.create(accountId,balance);
                printLine("account "+accountId+" created!", out);
            }
            catch (Exception ex) {
                printLine("account "+accountId+" already exist!", out);
                acc = home.findByPrimaryKey(accountId);
            }
            printLine("",out);
            printLine("Account Number: "+acc.getPrimaryKey(), out);
            printLine("Balance:        "+acc.balance(), out);
            printLine("", out);

            printLine("Making a deposit ...", out);
            try {
                acc.deposit(1000);
            }
            catch (Exception ex) {

            }

            printLine("",out);
            printLine("Account Number: "+acc.getPrimaryKey(), out);
            printLine("New Balance:        "+acc.balance(), out);
            printLine("", out);

            printLine("Deleting account ...", out);
            try {
                acc.remove();
            }
            catch (Exception ex) {

            }

        }
        catch (Exception e) {
            printLine("Exception catched", out);
            e.printStackTrace();
        }
        finally {
            printLine("", out);
            printLine("End HitSW testing beanManaged.Servlet...", out);
        }

        out.println( "</body></html>" );
        //out.flush();
    }

    /**
     * Basic servlet information.
     */
    public String getServletInfo() {
        return "Hit Testing EJBean Servlet";
    }

    /**
     * Prints message to browser.
     */
    static private void printLine(String message, PrintWriter out)
        throws IOException {
	out.println( "<br>" );
	out.println( message );
    }

    /**
     * Gets an initial context for the current user, password and url.
     */
    static public Context getInitialContext() throws Exception {
        Properties p = new Properties();
        p.put(Context.INITIAL_CONTEXT_FACTORY,
              "weblogic.jndi.WLInitialContextFactory");
        return new InitialContext(p);
    }
}

