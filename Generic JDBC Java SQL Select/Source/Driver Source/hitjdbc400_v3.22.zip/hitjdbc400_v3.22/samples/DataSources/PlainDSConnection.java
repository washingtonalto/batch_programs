/**
 * @(#)PlainDSConnection.java
 *
 * This example shows how to use the Hit's As400DataSource
 * that was created by the application DataSourceAdmin.java
 * Please run DataSourceAdmin before running this application.
 *
 * This application looks up the plain data source name "jdbc/hitas400plain",
 * opens a connection to the database and allows user to execute SQL statements.
 *
 * IMPORTANT NOTE:
 * You need to use the same context factory as when youn run DataSourceAdmin.
 * For example, to run this application:
 * java -Djava.naming.factory.initial=hit.jndi.jdbccontext.JDBCNameContextFactory PlainDSConnection
 *
 * <pre>Copyright (C) 2001 by Hit Software, Inc. All rights reserved.</pre>
 */

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import java.lang.*;
import java.io.*;
import java.sql.*;
import javax.sql.*;

public class PlainDSConnection {

    public PlainDSConnection () {}

    public static void main(String args[]) {

        DataSource ds; // Data source for connections

        try {
            // Uncomment next line to generate JDBC trace
            //DriverManager.setLogWriter(new PrintWriter(new FileOutputStream("PlainDSConnection.log")));

            // Make sure that "java.naming.factory.initial" is set when running this application
            System.out.print("Initializing context...");
            Context ctx = new InitialContext();
            System.out.println("OK.");

            // Look up the data source named "jdbc/hitas400plain"
            // We assume that "jdbc/hitas400plain" was bound by DataSourceAdmin.java
            System.out.print("Looking up data source name \"jdbc/hitas400plain\"...");
		    ds = (DataSource) ctx.lookup("jdbc/hitas400plain");
            System.out.println("OK.");

            // Get a connection
            System.out.print("Opening a new connection...");
            Connection connection = ds.getConnection();
            System.out.println("OK.");

            System.out.println("Ready to execute SQL statements.");

            BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
            String userInput;

            // Looping to accept and execute SQL statements
            // until an EOL character is entered (CTRL-Z or CTRL-D)
            while (true) {
                System.out.print("SQL> ");
                if ((userInput = in.readLine()) == null) break;
				if (userInput.trim().length() == 0) continue;
                try {
                    Statement stmnt = connection.createStatement();
                    boolean isResult = stmnt.execute(userInput);
                    for (boolean hasMore = true ; hasMore ; ) {
                        if (isResult) {
                            ResultSet resultSet = stmnt.getResultSet();
                            printResultSet("", resultSet);
                        } else {
                            int updateCount = stmnt.getUpdateCount();
                            if (updateCount >= 0) System.out.println("Update count: " + updateCount);
                            if (updateCount < 0) hasMore = false;
                        }
                        if (hasMore) isResult = stmnt.getMoreResults();
                    }
                    stmnt.close();
                }
                catch (SQLException e) {
                    System.err.println("SQL Exception: " + e.getMessage());
                    System.err.println("SQL State:     " + e.getSQLState());
                    System.err.println("Vendor Code:   " + e.getErrorCode());
                }
                catch (Exception oe) {
                    oe.printStackTrace(System.err);
                }
            } // end for
            connection.close();
        }
        catch (Exception ex) {
            System.err.println("Exception: " + ex.getMessage());
        }
    }

    static void printResultSet(String msg, ResultSet rs)
    {
        try {
            System.out.println(msg);
			ResultSetMetaData rsmd = rs.getMetaData();
            System.out.println(rsmd.toString()+"\n");
            for (int i=0; rs.next();) {
                System.out.print("#" + (++i) + " ");
   			    for (int j = 1; j <= rsmd.getColumnCount(); j++) {
                    if (j == 1) System.out.print("<");
                    String s = null;
                    try {
                        s = rs.getString(j);
                    } catch (Exception e2) {
                        System.out.print(e2.getMessage());
                    }
                    s = (s == null) ? "null" : s.trim();
                    try {
                        System.out.print(s);
                    } catch (Exception e1) {
                        System.out.print(e1.getMessage());
                    }
                    System.out.print((j == rsmd.getColumnCount()) ? ">" : ", ");
                }
                System.out.println("");
            }
            System.out.println("");
        } catch (Exception e) {System.out.println("Print Exception: " + e.getMessage());}
    }

}

