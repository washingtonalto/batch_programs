/**
 * @(#)DataSourceAdmin.java
 *
 * This application contains sample codes showing how to configure
 * both normal and connection pooling data sources.
 *
 * Typically, user applications do not create, configure and bind
 * data sources. These tasks are normally handled by an administrative
 * application like this one.
 *
 * This application creates, configures and binds 3 data sources,
 * 2 of which can be used by the other sample applications.
 * Please see:
 *     PlainDSConnection.java  - uses the plain data source created here
 *     PooledDSConnection.java - uses the pooled connection data source
 *
 * As400DataSource is Hit's implementation of DataSource without connection pooling
 * As400ConnectionPoolDataSource is Hit's implementation of ConnectionPoolDataSource
 * As400PooledDataSource is Hit's implementation of DataSource for connection pooling
 *
 * Note that all of Hit's data sources here uses the hit driver "hit.as400.As400Driver"
 *
 * IMPORTANT NOTE:
 * Do not forget to edit the connection properties for your database in this file.
 * Because As400PooledDataSource uses the default initial context InitialContext()
 * to lookup the name for its data source (As400ConnectionPoolDataSource), the default
 * intial context factory must be specified before or when the application is run.
 * For example, to run this application
 * java -Djava.naming.factory.initial=hit.jndi.jdbccontext.JDBCNameContextFactory DataSourceAdmin
 *
 * <pre>Copyright (C) 2001 by Hit Software, Inc. All rights reserved.</pre>
 */

import javax.naming.*;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import java.util.Hashtable;

import java.lang.*;
import java.io.*;
import java.sql.*;
import javax.sql.*;

public class DataSourceAdmin {

    public DataSourceAdmin () {}

    public static void main(String args[]) {

        try {
            // Uncomment next line to generate JDBC trace
            //DriverManager.setLogWriter(new PrintWriter(new FileOutputStream("DataSourceAdmin.log")));

            // Create the initial context using Hit's own jdbc context factory
            // Make sure that "java.naming.factory.initial" is set when running this application
		    Context ctx = new InitialContext();

            // Create and bind a As400DataSource.
            // A As400DataSource is a plain implementation of DataSource that
            // retuns real connections to applications (no connection pooling)

            // Create new instance of a plain data source
            hit.as400.As400DataSource plainDS = new hit.as400.As400DataSource();

            // Set connection properties for the data source
            plainDS.setServerName("1.1.1.1");                             // Server name or address
            plainDS.setDatabaseName("sample");                            // Libraries
            plainDS.setPortNumber(8471);                                  // Port number
			plainDS.setConnectionOptions("fetch_block_size=32");          // As400Driver connection options
			plainDS.setUser("jsmith");
		    plainDS.setPassword("secret");

            if (plainDS.getServerName().equals("1.1.1.1")) {
                System.out.println("Please edit this application to specify your own database properties before running!!!");
                throw new Exception("No good database properties");
            }

            // Bind data source to name "jdbc/hitas400plain" so that it can be
            // looked up and used later by user applications.
            // See the sample application PlainDSConnection.java.
            try {
                // we call rebind() rather than bind() here
                // If we use bind() we would get an exception after the first time
			    ctx.rebind("jdbc/hitas400plain", plainDS);
			    //ctx.bind("jdbc/hitas400plain", plainDS); // uncomment this line to try!
            } catch (Exception be) {
	            System.out.println(be);
            }

            // Using a connection pooling data source actually requires two data sources:
            // one that implements DataSource and the other that implements
            // As400PooleConnectionDataSource which is connection (PooledConnection) factory.
            // The DataSource's implementation uses As400PooledDataSource as a connection
            // factory while it manages the pool of connections.
            // An administrative application like this will create both type of classes
            // but a user application only use the DataSource implementation and does
            // not care and doesn't know anything about the As400PooleConnectionDataSource
            // behind the scene.

            // Create and bind a As400PooledDataSource and a As400ConnectionPoolDataSource.
            // A As400PooledDataSource is a DataSource that implements connection pooling management.
            // A As400PooledDataSource does not create the actual physical connections,
            // rather it relies on As400ConnectionPoolDataSource as the connection factory.

            // Create new instance of a pool connection factory As400ConnectionPoolDataSource
            hit.as400.As400ConnectionPoolDataSource cpds = new hit.as400.As400ConnectionPoolDataSource();

            // Set connection properties for the data source (connection factory)
			cpds.setServerName("1.1.1.1");  // Server name or address
            cpds.setDatabaseName("mylib");  // Libraries
			cpds.setUser("jsmith");         // Username
		    cpds.setPassword("secret");     // Password

            if (cpds.getServerName().equals("1.1.1.1")) {
                System.out.println("Please edit this application to specify your own database properties before running!!!");
                throw new Exception("No good database properties");
            }

            // Bind data source to name "jdbc/pool/as400sample"
            // This name will be used as data source for a As400PooledDataSource later
            // This data source is not meant to be used by an end-user application
            try {
                // we call rebind() rather than bind() here
                // If we use bind() we would get an exception
                // if we run this application more than once
			    ctx.rebind("jdbc/pool/as400sample", cpds);
			    //ctx.bind("jdbc/pool/as400sample", cpds); // uncomment this line to try!
            } catch (Exception be) {
	            System.out.println(be);
            }

            // Create new instance of As400PooledDataSource which implements connection pooling management
            hit.as400.As400PooledDataSource pooledDS = new hit.as400.As400PooledDataSource();

            // Set connection properties for the connection pooling data source
            pooledDS.setDataSourceName("jdbc/pool/as400sample"); // Data source name of PooledConnection object factory
            pooledDS.setMaxConnections(10);                 // Maximum number of concurrent connection allowed
            pooledDS.setOptimalConnections(5);              // Option number of connection to remain opened

            // Bind data source to name "jdbc/hitas400pooled" so that it can be
            // looked up and used later by user applications.
            // See the sample application PooledDSConnection.java.
            try {
                ctx.rebind("jdbc/hitas400pooled", pooledDS);
            } catch (Exception e) {
                System.out.println(e);
                e.printStackTrace();
            }

        }
        catch (Exception e) {
            System.out.println("Exception: " + e.getMessage());
            e.printStackTrace();
        }
    }
}

