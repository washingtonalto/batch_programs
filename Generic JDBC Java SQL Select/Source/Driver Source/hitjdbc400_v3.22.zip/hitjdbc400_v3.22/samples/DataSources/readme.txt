These three sample applications show you how to create,
configure and use Hit Software's implemetation of JDBC 2.0
DataSource for both normal and pooled connection
(connection pooling). Please read the comments in the
source code for more detailed descriptions.

DataSourceAdmin - is used to create and congigure the data
                  sources used by the other two application

PlainDSConnection - shows how to use hit.as400.As400DataSource class

PooledDSConnection - shows how to use hit.as400.As400PooledDataSource class
                     which is a data source that implements connection pooling

You can use the file r.bat to run the applications.

Make sure you edit and compile the files to specify your own database information.

Make sure you edit r.bat to privide appropriate path names for your system.

NOTE: Our driver's connection pooling implementation requires the property
      java.naming.factory.initial be set to hit.jndi.jdbccontext.JDBCNameContextFactory.
      You can set it on the command line as shown in the file r.bat or
      you can also set it to be used by default if you include it in a file
      named "jndi.properties" under the JAVA_HOME/lib/, where JAVA_HOME
      is the file directory that contains your JRE. For example, on Windows,
      if you installed your JDK under c:\jdk122 then you want to put
      "jndi.properties" under c:\jdk122\jre\lib. (You don't need to set the
      property on the command line if you have the correct default value)
      You can copy and use the file "jndi.properties" included here.
